/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caso1_t2;

import java.util.ArrayList;

public class Estudiante {
    private String nombre;
    private ArrayList<String> asistencia;

    public Estudiante(String nombre) {
        this.nombre = nombre;
        this.asistencia = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void registrarAsistencia(Clase clase, String estado) {
        String registro = clase.getNombre() + ": " + estado;
        asistencia.add(registro);
    }

    public void mostrarAsistencia() {
        System.out.println("----- Asistencia de " + nombre + " -----");
        for (String registro : asistencia) {
            System.out.println(registro);
        }
        System.out.println();
    }
}
