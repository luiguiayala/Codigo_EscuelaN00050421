
package caso1_t2;

import java.util.ArrayList;
public class Aula {
    private int capacidad;
    private ArrayList<Clase> clases;

    public Aula(int capacidad) {
        this.capacidad = capacidad;
        this.clases = new ArrayList<>();
    }

    public void agregarClase(Clase clase) {
        clases.add(clase);
    }

    public void mostrarClases() {
        System.out.println("----- Clases en el Aula -----");
        for (Clase clase : clases) {
            System.out.println(clase.getNombre());
        }
    }

    Iterable<Clase> getClases() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}