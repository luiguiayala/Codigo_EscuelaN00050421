
package caso1_t2;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class Asistencia {
    private Clase clase;
    private ArrayList<Estudiante> estudiantes;
    private Date fecha;

    public Asistencia(Clase clase) {
        this.clase = clase;
        this.estudiantes = new ArrayList<>();
        this.fecha = new Date();
    }

    public void tomarAsistencia() {
        System.out.println("----- Tomar Asistencia -----");
        System.out.println("Clase: " + clase.getNombre());
        System.out.println("Fecha: " + fecha);
        System.out.println("Ingrese 'P' si el estudiante está presente, 'A' si está ausente.");

        Scanner scanner = new Scanner(System.in);
        for (Estudiante estudiante : estudiantes) {
            System.out.print(estudiante.getNombre() + ": ");
            String asistencia = scanner.nextLine();
            estudiante.registrarAsistencia(clase, asistencia);
        }
    }

    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }
}