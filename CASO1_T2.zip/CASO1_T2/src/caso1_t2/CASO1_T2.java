
package caso1_t2;

import java.util.Scanner;

public class CASO1_T2 {

 
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        Aula aula = new Aula(10);
        Profesor profesor = new Profesor("Luigui Ayala");

        Clase claseManana = new Clase("Clase de la mañana");
        claseManana.agregarEstudiante(new Estudiante("Estudiante 1"));
        claseManana.agregarEstudiante(new Estudiante("Estudiante 2"));

        Clase claseTarde = new Clase("Clase de la tarde");
        claseTarde.agregarEstudiante(new Estudiante("Estudiante 3"));
        claseTarde.agregarEstudiante(new Estudiante("Estudiante 4"));

        Clase claseNoche = new Clase("Clase de la noche");
        claseNoche.agregarEstudiante(new Estudiante("Estudiante 5"));
        claseNoche.agregarEstudiante(new Estudiante("Estudiante 6"));

        aula.agregarClase(claseManana);
        aula.agregarClase(claseTarde);
        aula.agregarClase(claseNoche);
        int opcion;
        do {
            System.out.println("----- Menú -----");
            System.out.println("1. Mostrar clases en el aula");
            System.out.println("2. Tomar asistencia");
            System.out.println("3. Mostrar asistencia de un estudiante");
            System.out.println("0. Salir");
            System.out.print("Ingrese su opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    aula.mostrarClases();
                    break;
                    case 2:
                     System.out.println("Ingrese el número de la clase para tomar asistencia:");
                    aula.mostrarClases();
                    int numClase = scanner.nextInt();
                    if (numClase >= 1) {
                    Clase claseSeleccionada = null;
                    int contador = 1;
                    for (Clase clase : aula.getClases()) {
                     if (contador == numClase) {
                      claseSeleccionada = clase;
                   break;
                    }
                  contador++;
                }
               if (claseSeleccionada != null) {
               profesor.tomarAsistencia(claseSeleccionada);
                } else {
                System.out.println("Número de clase inválido.");
               }
              } else {
             System.out.println("Número de clase inválido.");
              }
           break;

                 


                case 3:
                    System.out.println("Ingrese el nombre del estudiante:");
                    scanner.nextLine(); // Limpiar el buffer
                    String nombreEstudiante = scanner.nextLine();
                    Estudiante estudianteSeleccionado = null;
                    for (Clase clase : aula.getClases()) {
                        for (Estudiante estudiante : clase.getEstudiantes()) {
                            if (estudiante.getNombre().equals(nombreEstudiante)) {
                                estudianteSeleccionado = estudiante;
                                break;
                            }
                        }
                        if (estudianteSeleccionado != null) {
                            break;
                        }
                    }
                    if (estudianteSeleccionado != null) {
                        estudianteSeleccionado.mostrarAsistencia();
                    } else {
                        System.out.println("Estudiante no encontrado.");
                    }
                    break;
                case 0:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
                    break;
            }
        } while (opcion != 0);
    }
}



        
  
   
   
