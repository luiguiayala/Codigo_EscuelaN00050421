
package caso1_t2;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

class Profesor {
    private String cod;
    private String nombre;
    private String apellidos;
    private int edad;
    public Profesor(String nombre) {
        this.nombre = nombre;
    }

    public void tomarAsistencia(Clase clase) {
        System.out.println("----- Tomar Asistencia -----");
        System.out.println("Clase: " + clase.getNombre());
        System.out.println("Fecha: " + new Date());
        System.out.println("Profesor: " + nombre);
        System.out.println("Ingrese 'P' si el estudiante está presente, 'A' si está ausente.");

        Scanner scanner = new Scanner(System.in);
        for (Estudiante estudiante : clase.getEstudiantes()) {
            System.out.print(estudiante.getNombre() + ": ");
            String asistencia = scanner.nextLine();
            estudiante.registrarAsistencia(clase, asistencia);
        }
    }
}