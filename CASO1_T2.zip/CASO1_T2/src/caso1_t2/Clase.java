
package caso1_t2;

import java.util.ArrayList;

public class Clase {
    private String nombre;
    private ArrayList<Estudiante> estudiantes;

    public Clase(String nombre) {
        this.nombre = nombre;
        this.estudiantes = new ArrayList<>();
    }

    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<Estudiante> getEstudiantes() {
        return estudiantes;
    }

}